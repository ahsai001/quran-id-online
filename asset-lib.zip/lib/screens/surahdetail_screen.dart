import 'package:flutter/material.dart';
import 'package:quran_id/models/surah_detail_response.dart';
import 'package:quran_id/models/surah_list_response.dart';
import 'package:quran_id/services/app_service.dart';

class SurahDetailScreen extends StatelessWidget {
  final SurahListItem item;
  const SurahDetailScreen({super.key, required this.item});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(item.namaLatin ?? ""),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: FutureBuilder<SurahDetailResponse>(
            future: AppService.quranService.getSurahDetail(item.nomor ?? 0),
            builder: (context, snapshot) {
              if ((snapshot.connectionState == ConnectionState.none &&
                      snapshot.hasData == false) ||
                  (snapshot.connectionState == ConnectionState.waiting)) {
                return const Center(child: CircularProgressIndicator());
              } else if (snapshot.hasError) {
                return Center(
                  child: Text("Ada masalah ${snapshot.error.toString()}"),
                );
              }
              final response = snapshot.data!;
              return ListView.separated(
                  itemBuilder: (context, index) {
                    final ayatItem = response.ayat![index];
                    return ListTile(
                      title: Text(
                        ayatItem.ar ?? "",
                        style:
                            const TextStyle(fontFamily: "usmani", fontSize: 30),
                      ),
                      subtitle: Text(ayatItem.idn ?? ""),
                    );
                  },
                  separatorBuilder: (context, index) {
                    return const Divider();
                  },
                  itemCount: response.ayat?.length ?? 0);
            }),
      ),
    );
  }
}
